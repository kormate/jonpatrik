const words = ["Talán", "Lehet", "Igen", "Tuti"];
const finalw = "Nem";
const round = 5;
const intervalTime = 150;

const WordContainer = document.getElementById("word-container");

let wordIndex = 0;
let count = 0;

const intervalId = setInterval(() =>{
    WordContainer.textContent = words[wordIndex];
    wordIndex = (wordIndex + 1) % words.length;

    if (wordIndex === 0){
        count++;
    }

    if (count >= round){
        clearInterval(intervalId);
        WordContainer.textContent = finalw;
    }
}, intervalTime);